# `@tender/sdk`

Typed npm client for EmDash plugin authors that call Tender. Provides request validation, idempotency key generation, and provider delegation.

## Installation

```bash
pnpm install @tender/sdk
```

## Key Features

- **Charge API**: Create one-time transactions with automatic idempotency keys
- **Subscription API**: Create and manage subscription plans and customer subscriptions
- **Refund API**: Full and partial refund requests with idempotency
- **Type Safety**: Fully typed request/response interfaces for all operations
- **Input Validation**: Rejects raw card data (PAN, CVV, expiry) at the API boundary
- **Provider Delegation**: Routes to appropriate provider plugin based on account configuration

## Usage

```typescript
import { tender } from '@tender/sdk';

// Create a charge (idempotency key auto-generated)
const result = await tender.charge({
  amount: 9999, // cents
  currency: 'USD',
  provider: 'stripe',
  metadata: { invoiceId: 'inv_123' }
});

// Create a subscription
const subscription = await tender.subscription.create({
  planId: 'plan_stripe_monthly',
  customerId: 'cust_square_abcd',
  metadata: {}
});
```

## License

MIT
